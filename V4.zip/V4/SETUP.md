# Comment backend + hosting setup (all on Firebase, free)

Comments use **Firebase Firestore**, a free shared database that every
visitor's browser can read/write directly, with rules that enforce your
approve/reject workflow. Since Firebase can also host the site itself
(**Firebase Hosting**), there's no need for GitHub Pages — everything
lives in one project.

## 1. Create a free Firebase project
1. Go to https://console.firebase.google.com → **Add project** → give it
   any name (e.g. `chat-comix`) → finish the wizard. No credit card needed
   on the free "Spark" plan.

## 2. Register a web app
1. In the project, click the **</>** (web) icon → register an app
   (nickname can be anything).
2. Copy the `firebaseConfig` object it shows you.
3. Paste those values into **`firebase-config.js`** in this folder,
   replacing the placeholders.

## 3. Turn on Firestore
1. Left menu → **Build → Firestore Database** → **Create database** →
   start in **production mode** → pick any region → Enable.
2. Go to the **Rules** tab, delete the default rules, paste in the
   contents of **`firestore.rules.txt`**, then click **Publish**.

## 4. Turn on your admin login
1. Left menu → **Build → Authentication** → **Get started**.
2. Under **Sign-in method**, enable **Email/Password**.
3. Go to the **Users** tab → **Add user** → enter the email/password
   you want to use to log into `admin.html`.

## 5. Install the Firebase CLI (one-time, needs Node.js)
```
npm install -g firebase-tools
firebase login
```
This opens a browser window to sign in with the same Google account you
used for the Firebase console.

## 6. Initialize Hosting in this folder
From inside the `ComicRoll` folder (the one with `index.html`, `admin.html`,
`style.css`, `app.js`, `firebase-config.js`, `chat-manifest.js`, and the
`strips/` folder):
```
firebase init hosting
```
When prompted:
- **Which project?** → select the one you created in step 1.
- **Public directory?** → `.` (a dot, meaning "this folder itself").
- **Single-page app?** → No.
- **Set up automatic builds with GitHub?** → No (unless you want that later).
- **Overwrite index.html?** → No (keep your existing file).

This creates `firebase.json` and `.firebaserc` in the folder — leave those
as they are.

## 7. Deploy
```
firebase deploy
```
When it finishes, it prints your live URL, something like:
```
https://chat-comix.web.app
```
That's your site — share that link with visitors. Re-run `firebase deploy`
any time you make changes to re-publish them.

## How it behaves afterwards
- A visitor posts a comment → saved as **pending** → hidden from everyone.
- You log into `admin.html` with the email/password from step 4 →
  **Comment moderation** panel shows every comment (pending/approved/
  rejected) → **Approve**, **Reject**, or **Delete**.
- The moment you approve one, it appears for **every visitor, on every
  browser**, immediately — no manual file editing, no re-deploying needed
  just to publish a comment.

Reactions and the visitor/traffic log are unchanged and still stored only
in each visitor's own browser (`localStorage`), since that wasn't part of
this request.
