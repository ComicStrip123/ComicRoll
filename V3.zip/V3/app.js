/* =====================================================================
   SETTINGS
   - Create numbered folders inside "strips": strips/1/, strips/2/, strips/3/ ...
   - Inside each folder put the matching file: strips/1/1.html, strips/2/2.html, etc. Keep each HTML chat and its related images together.
   - The site finds them automatically: 10 images = 10 strips.
   - Titles and dates below are OPTIONAL. Missing ones show "Strip N".
   - Comments are stored in Firebase (see firebase-config.js) so every
     visitor, on every browser, sees the same approved comments.
   ===================================================================== */
var STRIP_FOLDER = "strips/";
var CHAT_MANIFEST = window.CHAT_MANIFEST || [];
var EXTENSIONS = ["bmp", "jpg", "jpeg", "png", "webp", "gif", "svg"];
var STRIP_INFO = {
  1: { title: "Friday Deploy",   date: "4 Sep 2026" },
  2: { title: "Ask the Bot",     date: "11 Sep 2026" },
  3: { title: "Keyboard Cat",    date: "18 Sep 2026" },
  4: { title: "Password Policy", date: "25 Sep 2026" }
};
var CAST = {
  max: { name: "Max", emoji: "🦸", colour: "#FFD6C9", bio: "Self-proclaimed coding hero. Never reads the documentation and always deploys on Fridays.", traits: ["Brave", "Chaotic", "Snack-powered"], quote: "It works on my machine!" },
  zoe: { name: "Zoe", emoji: "🧠", colour: "#D9D0FF", bio: "The calm genius who fixes everything Max breaks. Runs on green tea and sarcasm.", traits: ["Smart", "Sarcastic", "Organised"], quote: "Did you even test it?" },
  bob: { name: "Bob the Bot", emoji: "🤖", colour: "#C8F4E8", bio: "An overly enthusiastic AI assistant who takes everything literally.", traits: ["Helpful", "Literal", "Beep-boop"], quote: "Processing... still processing..." },
  kat: { name: "Kat", emoji: "🐱", colour: "#FFEFC2", bio: "The office cat. Nobody knows who owns her. She sits on keyboards at the worst moments.", traits: ["Mysterious", "Fluffy", "Chaos agent"], quote: "Meow. (Deletes prod.)" }
};
var REACTIONS = [["😂", "Funny"], ["😍", "Love it"], ["🔥", "Fire"], ["😮", "Wow"], ["😢", "Sad"]];
/* ---------- helpers ---------- */
var STRIPS = [];
function el(id) { return document.getElementById(id); }
function load(k, f) { try { return JSON.parse(localStorage.getItem(k)) || f; } catch (e) { return f; } }
function save(k, v) { localStorage.setItem(k, JSON.stringify(v)); }
function safe(t) { var d = document.createElement("div"); d.textContent = t; return d.innerHTML; }
function announce(m) { el("live").textContent = ""; setTimeout(function () { el("live").textContent = m; }, 50); }
/* ---------- Firestore comments collection (shared across every visitor) ---------- */
function commentsCol() { return db.collection("comments"); }
var approvedCommentCounts = {};
function refreshCommentCounts(cb) {
  commentsCol().where("status", "==", "approved").get().then(function (snap) {
    var counts = {};
    snap.forEach(function (doc) { var sid = doc.data().stripId; counts[sid] = (counts[sid] || 0) + 1; });
    approvedCommentCounts = counts;
    if (cb) cb();
  }).catch(function () { if (cb) cb(); });
}
/* ---------- find images in the strips folder ---------- */
function tryImage(src) {
  return new Promise(function (ok) { var i = new Image(); i.onload = function () { ok(src); }; i.onerror = function () { ok(null); }; i.src = src; });
}
function findStrip(n) {
  var i = 0;
  function next() {
    if (i >= EXTENSIONS.length) return Promise.resolve(null);
    var ext = EXTENSIONS[i++]; return tryImage(STRIP_FOLDER + n + "." + ext).then(function (src) { return src || next(); });
  }
  return next();
}
function discover(n) {
  var chat = CHAT_MANIFEST.find(function (c) { return Number(c.id) === n; });
  if (chat) {
    STRIPS.push({ id: n, src: chat.src, type: "html", title: chat.title || ("Chat " + n), date: chat.date || "", description: chat.description || "" });
    return discover(n + 1);
  }
  return findStrip(n).then(function (src) {
    if (!src) return;
    var info = STRIP_INFO[n] || {};
    STRIPS.push({ id: n, src: src, type: "image", title: info.title || "Strip " + n, date: info.date || "" });
    return discover(n + 1);
  });
}
/* ---------- rendering ---------- */
function stats(id) {
  var r = load("cx_react", {})[id] || {}, t = 0;
  Object.keys(r).forEach(function (k) { t += r[k]; });
  var c = approvedCommentCounts[String(id)] || 0;
  return { reacts: t, comments: c };
}
function card(s, displayIndex) {
  var st = stats(s.id), isHtml = s.type === "html";
  var tagline = isHtml ? safe(s.description || "Fun Chat") : "";
  var badge = "#" + (displayIndex + 1);
  var preview = isHtml ? '<div class="s-img html-preview"><div class="html-icon">💬</div><strong>' + tagline + '</strong><span>Tap to open</span><span class="zoom">↗ Open</span></div>' : '<div class="s-img"><img src="' + s.src + '" alt="" loading="lazy"><span class="zoom">⛶ View</span></div>';
  return '<button class="strip" data-strip="' + s.id + '"><div class="s-top"><h3>' + safe(s.title) + '</h3><span class="s-num">' + badge + '</span></div>' + preview + '<div class="s-foot"><span>' + safe(s.date) + '</span><span>💬 <b>' + st.comments + '</b> &nbsp; ❤️ <b>' + st.reacts + '</b></span></div></button>';
}
function renderStrips() {
  if (!STRIPS.length) {
    var msg = '<div class="empty"><h3>No strips yet 🙈</h3><p>Create numbered folders such as <code>strips/1/</code>, <code>strips/2/</code>. Inside each folder put the matching <code>1.html</code>, <code>2.html</code> and that chat\'s related images.</p></div>';
    el("latest").innerHTML = msg; el("allStrips").innerHTML = msg; el("stripCount").textContent = "0 strips"; return;
  }
  var newest = STRIPS.slice().reverse();
  el("latest").innerHTML = newest.slice(0, 3).map(card).join("");
  el("allStrips").innerHTML = newest.map(card).join("");
  el("stripCount").textContent = STRIPS.length + (STRIPS.length === 1 ? " strip" : " strips");
  var last = newest[0];
  el("heroSlot").innerHTML = last.type === "html"
    ? '<button class="hero-strip html-preview" data-strip="' + last.id + '" aria-label="Open the latest chat, ' + safe(last.title) + '"><div class="html-icon">💬</div><strong>' + safe(last.title) + '</strong><span>' + safe(last.description || "Open chat →") + '</span></button>'
    : '<button class="hero-strip" data-strip="' + last.id + '" aria-label="Open the latest strip, ' + safe(last.title) + '"><img src="' + last.src + '" alt=""></button>';
}
function renderCast() {
  el("charGrid").innerHTML = Object.keys(CAST).map(function (k) {
    var c = CAST[k];
    return '<button class="flip" aria-pressed="false" aria-label="' + c.name + '. ' + c.bio + ' Favourite line: ' + c.quote + '"><div class="flip-in" aria-hidden="true">' +
      '<div class="face front"><div class="big-av" style="background:' + c.colour + '">' + c.emoji + '</div><h3>' + c.name + '</h3><div>' +
      c.traits.map(function (t) { return '<span class="trait">' + t + '</span>'; }).join("") + '</div><span class="hint">Tap to see backstory ↻</span></div>' +
      '<div class="face back"><h3>' + c.name + '</h3><p>' + c.bio + '</p><q>' + c.quote + '</q></div></div></button>';
  }).join("");
}
/* ---------- navigation ---------- */
function go(page) {
  document.querySelectorAll(".page").forEach(function (p) { p.classList.toggle("on", p.id === page); });
  document.querySelectorAll(".menu button, .tabbar button").forEach(function (b) {
    if (b.dataset.go === page) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current");
  });
  document.title = { home: "Home", strips: "Strips", chars: "Cast", about: "About" }[page] + " · Chat Comix";
  window.scrollTo(0, 0); el("main").focus({ preventScroll: true });
  logVisit(page);
}
document.addEventListener("click", function (e) {
  var nav = e.target.closest("[data-go]"); if (nav) { go(nav.dataset.go); return; }
  var s = e.target.closest("[data-strip]"); if (s) { openViewer(+s.dataset.strip); return; }
  var f = e.target.closest(".flip"); if (f) f.setAttribute("aria-pressed", f.getAttribute("aria-pressed") !== "true");
});
/* ---------- full-screen viewer ---------- */
var cur = null, lastFocus = null;
function openViewer(id) {
  lastFocus = document.activeElement;
  cur = STRIPS.find(function (s) { return s.id === id; });
  showStrip();
  el("overlay").classList.add("on");
  document.body.style.overflow = "hidden";
  el("vTitle").focus();
}
function closeViewer() {
  el("overlay").classList.remove("on");
  document.body.style.overflow = "";
  setZoom(false);
  refreshCommentCounts(function () { renderStrips(); });
  var again = document.querySelector('[data-strip="' + cur.id + '"]');
  (again || lastFocus || el("main")).focus();
}
function showStrip() {
  var i = STRIPS.indexOf(cur);
  setZoom(false);
  var isHtml = cur.type === "html";
  el("vImg").style.display = isHtml ? "none" : "block"; el("vFrame").style.display = isHtml ? "block" : "none"; el("zoomBtn").style.display = isHtml ? "none" : "inline-block";
  if (isHtml) el("vFrame").src = cur.src; else { el("vImg").src = cur.src; el("vImg").alt = "Comic strip " + cur.id + ": " + cur.title; }
  el("vTitle").textContent = cur.title;
  el("vChip").textContent = "Strip #" + cur.id + (cur.date ? " · " + cur.date : "") + " · " + (i + 1) + " of " + STRIPS.length;
  el("prevBtn").disabled = i === 0;
  el("nextBtn").disabled = i === STRIPS.length - 1;
  var v = load("cx_views", {}); v[cur.id] = (v[cur.id] || 0) + 1; save("cx_views", v);
  logVisit("strip #" + cur.id);
  drawFeedback();
}
function step(d) {
  var i = STRIPS.indexOf(cur) + d;
  if (i < 0 || i >= STRIPS.length) return;
  cur = STRIPS[i]; showStrip(); announce("Strip " + cur.id + ": " + cur.title);
}
function setZoom(on) {
  el("stage").classList.toggle("zoomed", on);
  el("zoomBtn").setAttribute("aria-label", on ? "Fit to screen" : "Zoom in");
  el("zoomBtn").textContent = on ? "⤢" : "🔍";
}
el("zoomBtn").onclick = function () { setZoom(!el("stage").classList.contains("zoomed")); };
el("vImg").onclick = function () { setZoom(!el("stage").classList.contains("zoomed")); };
el("closeBtn").onclick = closeViewer;
el("prevBtn").onclick = function () { step(-1); };
el("nextBtn").onclick = function () { step(1); };
el("stage").onclick = function (e) { if (e.target === el("stage")) closeViewer(); };
el("panelToggle").onclick = function () {
  var closed = el("vPanel").classList.toggle("closed");
  this.setAttribute("aria-expanded", !closed);
  this.textContent = (closed ? "▸ " : "▾ ") + "Reactions & comments";
};
/* swipe left/right on phones */
var sx = null;
el("stage").addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; }, { passive: true });
el("stage").addEventListener("touchend", function (e) {
  if (sx === null || el("stage").classList.contains("zoomed")) return;
  var dx = e.changedTouches[0].clientX - sx; sx = null;
  if (Math.abs(dx) > 60) step(dx < 0 ? 1 : -1);
});
/* ---------- reactions (still local to each browser) ---------- */
function drawFeedback() {
  var r = load("cx_react", {})[cur.id] || {}, mine = load("cx_mine", {})[cur.id];
  el("emos").innerHTML = REACTIONS.map(function (x) {
    return '<button data-react="' + x[0] + '" aria-pressed="' + (mine === x[0]) + '" aria-label="' + x[1] + ', ' + (r[x[0]] || 0) + ' votes"><span aria-hidden="true">' + x[0] + '</span><small aria-hidden="true">' + (r[x[0]] || 0) + '</small></button>';
  }).join("");
  el("emos").querySelectorAll("[data-react]").forEach(function (b) { b.onclick = function () { react(b.dataset.react); }; });
  drawComments();
}
/* ---------- comments (shared via Firestore, moderated in admin.html) ---------- */
function drawComments() {
  el("cHead").textContent = "Comments";
  el("cList").innerHTML = '<li class="hint">Loading comments…</li>';
  var stripId = String(cur.id);
  commentsCol().where("stripId", "==", stripId).where("status", "==", "approved").get().then(function (snap) {
    var list = [];
    snap.forEach(function (doc) { list.push(doc.data()); });
    list.sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); });
    el("cHead").textContent = "Comments (" + list.length + ")";
    el("cList").innerHTML = list.map(function (c) {
      return '<li class="comment"><strong>' + safe(c.name) + '</strong> <small>' + safe(c.when) + '</small><br>' + safe(c.text) + '</li>';
    }).join("") || '<li class="hint">No comments yet. Be the first!</li>';
  }).catch(function () {
    el("cHead").textContent = "Comments";
    el("cList").innerHTML = '<li class="hint">Could not load comments right now.</li>';
  });
}
function react(emoji) {
  var all = load("cx_react", {}), mine = load("cx_mine", {}), r = all[cur.id] || {}, prev = mine[cur.id];
  if (prev) r[prev] = Math.max(0, (r[prev] || 1) - 1);
  if (prev === emoji) { delete mine[cur.id]; announce("Reaction removed"); }
  else { r[emoji] = (r[emoji] || 0) + 1; mine[cur.id] = emoji; announce("Reacted " + emoji); }
  all[cur.id] = r; save("cx_react", all); save("cx_mine", mine);
  drawFeedback(); el("emos").querySelector('[data-react="' + emoji + '"]').focus();
}
el("cForm").onsubmit = function (e) {
  e.preventDefault();
  var text = el("cText").value.trim(); if (!text) return;
  var submitBtn = el("cForm").querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  /* status "pending" keeps the comment hidden from every visitor until
     an admin approves it in admin.html. Comments live in Firestore, so
     the review queue and the approved list are shared by everyone,
     not just this browser. */
  commentsCol().add({
    stripId: String(cur.id),
    name: el("cName").value.trim() || "Anonymous",
    text: text,
    when: new Date().toLocaleString(),
    ts: Date.now(),
    status: "pending"
  }).then(function () {
    el("cText").value = "";
    announce("Thanks! Your comment has been submitted and will appear once approved.");
  }).catch(function () {
    announce("Sorry, something went wrong posting your comment. Please try again.");
  }).finally(function () {
    submitBtn.disabled = false;
  });
};
/* ---------- keyboard ---------- */
document.addEventListener("keydown", function (e) {
  if (!el("overlay").classList.contains("on")) return;
  var typing = /INPUT|TEXTAREA/.test(document.activeElement.tagName);
  if (e.key === "Escape") closeViewer();
  if (!typing && e.key === "ArrowLeft") step(-1);
  if (!typing && e.key === "ArrowRight") step(1);
  if (!typing && (e.key === "z" || e.key === "Z")) el("zoomBtn").click();
  if (e.key === "Tab") {
    var f = Array.prototype.slice.call(el("overlay").querySelectorAll("button:not([disabled]), input, textarea"))
      .filter(function (x) { return x.offsetParent !== null; });
    if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
    else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
  }
});
/* ---------- visitor log (read by admin.html) ----------
   Captures IP address, location, ISP and device details.
   This part stays in localStorage: it is per-browser, used only to
   show basic traffic stats to you in admin.html on your own device.
   LOG_ENDPOINT: optional URL (e.g. an Azure Function) that receives each
   visit as JSON, so you can see visits from ALL devices, not just this browser. */
var LOG_ENDPOINT = "";
function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }
function visitorInfo() {
  var v = load("cx_visitor", null);
  if (!v) v = { id: "V-" + uid().toUpperCase(), first: new Date().toLocaleString(), visits: 0 };
  if (!sessionStorage.getItem("cx_session")) { sessionStorage.setItem("cx_session", "S-" + uid().toUpperCase()); v.visits++; }
  save("cx_visitor", v);
  return v;
}
var geoPromise = null;
function getGeo() {
  if (geoPromise) return geoPromise;
  var cached = sessionStorage.getItem("cx_geo");
  if (cached) return geoPromise = Promise.resolve(JSON.parse(cached));
  function keep(g) { sessionStorage.setItem("cx_geo", JSON.stringify(g)); return g; }
  geoPromise = fetch("https://ipapi.co/json/").then(function (r) { return r.json(); }).then(function (d) {
    if (!d.ip) throw 0;
    return keep({ ip: d.ip, city: d.city || "", region: d.region || "", country: d.country_name || "", postcode: d.postal || "", isp: d.org || "", lat: d.latitude || "", lon: d.longitude || "" });
  }).catch(function () {
    return fetch("https://api.ipify.org?format=json").then(function (r) { return r.json(); })
      .then(function (d) { return keep({ ip: d.ip }); })
      .catch(function () { return { ip: "Unavailable" }; });
  });
  return geoPromise;
}
var hintPromise = (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues)
  ? navigator.userAgentData.getHighEntropyValues(["model", "platformVersion"]).catch(function () { return {}; })
  : Promise.resolve({});
function deviceDetails() {
  var u = navigator.userAgent, m;
  var browser = /Edg\//.test(u) ? "Edge" : /OPR\//.test(u) ? "Opera" : /Chrome\//.test(u) ? "Chrome" : /Firefox\//.test(u) ? "Firefox" : /Safari\//.test(u) ? "Safari" : "Other";
  var bver = (m = u.match(/(?:Edg|OPR|Chrome|Firefox|Version)\/([\d.]+)/)) ? m[1].split(".")[0] : "";
  var os = "Other", osver = "";
  if ((m = u.match(/Windows NT ([\d.]+)/))) { os = "Windows"; osver = { "10.0": "10/11", "6.3": "8.1", "6.1": "7" }[m[1]] || m[1]; }
  else if ((m = u.match(/Android ([\d.]+)/))) { os = "Android"; osver = m[1]; }
  else if ((m = u.match(/OS ([\d_]+) like Mac/))) { os = "iOS"; osver = m[1].replace(/_/g, "."); }
  else if ((m = u.match(/Mac OS X ([\d_.]+)/))) { os = "macOS"; osver = m[1].replace(/_/g, "."); }
  else if (/Linux/.test(u)) os = "Linux";
  var conn = navigator.connection || {};
  return {
    type: /iPad|Tablet/i.test(u) ? "Tablet" : /Mobi|Android|iPhone/i.test(u) ? "Mobile" : "Desktop",
    os: os, osVersion: osver, browser: browser, browserVersion: bver,
    screen: screen.width + " x " + screen.height, viewport: innerWidth + " x " + innerHeight,
    pixelRatio: window.devicePixelRatio || 1, touch: ("ontouchstart" in window) ? "Yes" : "No",
    cores: navigator.hardwareConcurrency || "", memoryGB: navigator.deviceMemory || "",
    network: conn.effectiveType || "", lang: navigator.language,
    tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
    darkMode: matchMedia("(prefers-color-scheme: dark)").matches ? "Yes" : "No",
    ua: u
  };
}
function logVisit(page) {
  var v = visitorInfo(), entry = deviceDetails();
  entry.time = new Date().toLocaleString(); entry.page = page;
  entry.visitorId = v.id; entry.sessionId = sessionStorage.getItem("cx_session");
  entry.visitNo = v.visits; entry.firstSeen = v.first;
  entry.ref = document.referrer || "Direct";
  Promise.all([getGeo(), hintPromise]).then(function (r) {
    var g = r[0], hints = r[1];
    Object.keys(g).forEach(function (k) { entry[k] = g[k]; });
    entry.model = hints.model || "";
    if (entry.os === "Windows" && hints.platformVersion) entry.osVersion = parseInt(hints.platformVersion) >= 13 ? "11" : "10";
    var log = load("cx_log", []); log.push(entry); save("cx_log", log.slice(-1000));
    if (LOG_ENDPOINT) fetch(LOG_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(entry), keepalive: true }).catch(function () {});
  });
}
/* ---------- start ---------- */
renderCast();
logVisit("home");
refreshCommentCounts(function () {
  discover(1).then(function () {
    save("cx_strips", STRIPS.map(function (s) { return { id: s.id, title: s.title }; }));
    renderStrips();
  });
});
