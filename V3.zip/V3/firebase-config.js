/* =====================================================================
   FIREBASE CONFIG — fill this in with YOUR OWN free Firebase project.
   See SETUP.md for the full step-by-step guide.

   These values come from: Firebase console → ⚙ Project settings →
   "Your apps" → Web app → SDK setup and configuration.

   Note: this file is safe to commit to a public GitHub repo. These are
   publishable client identifiers, not secret keys — real protection
   comes from the Firestore security rules (see firestore.rules.txt),
   not from hiding this file.
   ===================================================================== */
var firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();
