window.CHAT_MANIFEST = [
  {
    "id": 3,
    "title": "SubbuLaxmi [started: 10:58 AM]",
    "src": "strips/3/3.html",
    "description": "Badey Log Banter: wedding plans, VPF drama, and a Bollywood casting joke."
  },
  {
    "id": 4,
    "title": "SubbuLaxmi [started: 2:36 PM]",
    "src": "strips/4/4.html"
  },
  {
    "id": 5,
    "title": "SubbuLaxmi [started: 10:58 AM]",
    "src": "strips/5/5.html"
  },
  {
    "id": 6,
    "title": "SubbuLaxmi [started: 1:42 PM]",
    "src": "strips/6/6.html"
  },
  {
    "id": 7,
    "title": "SubbuLaxmi [started: 12:39 PM]",
    "src": "strips/7/7.html"
  },
  {
    "id": 8,
    "title": "SubbuLaxmi [started: 9:22 AM]",
    "src": "strips/8/8.html"
  },
  {
    "id": 9,
    "title": "SubbuLaxmi [started: 2:00 PM]",
    "src": "strips/9/9.html"
  },
  {
    "id": 10,
    "title": "SubbuLaxmi [started: 4:11 PM]",
    "src": "strips/10/10.html"
  },
  {
    "id": 11,
    "title": "SubbuLaxmi [started: 5:14 PM]",
    "src": "strips/11/11.html"
  },
  {
    "id": 12,
    "title": "SubbuLaxmi [started: 12:17 PM]",
    "src": "strips/12/12.html"
  }
];
