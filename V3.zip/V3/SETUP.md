# Comment backend setup (free, works on GitHub Pages)

GitHub Pages only serves static files — it cannot run server code or write
to a text file for you. So comments use **Firebase Firestore**, a free
shared database that any visitor's browser can read/write directly, with
rules that still enforce your approve/reject workflow.

## 1. Create a free Firebase project
1. Go to https://console.firebase.google.com → **Add project** → give it
   any name (e.g. `chat-comix`) → finish the wizard. No credit card needed
   on the free "Spark" plan.

## 2. Register a web app
1. In the project, click the **</>** (web) icon → register an app
   (nickname can be anything, no hosting needed).
2. Copy the `firebaseConfig` object it shows you.
3. Paste those values into **`firebase-config.js`** in this folder,
   replacing the placeholders.

## 3. Turn on Firestore
1. Left menu → **Build → Firestore Database** → **Create database** →
   start in **production mode** → pick any region → Enable.
2. Go to the **Rules** tab, delete the default rules, paste in the
   contents of **`firestore.rules.txt`**, then click **Publish**.

## 4. Turn on your admin login
1. Left menu → **Build → Authentication** → **Get started**.
2. Under **Sign-in method**, enable **Email/Password**.
3. Go to the **Users** tab → **Add user** → enter the email/password
   you want to use to log into `admin.html`. (This replaces the old demo
   "admin" password.)

## 5. Upload to GitHub
1. Push `index.html`, `admin.html`, `style.css`, `app.js`,
   `firebase-config.js`, `chat-manifest.js`, and the `strips/` folder to
   your repo.
2. Enable **GitHub Pages** for the repo (Settings → Pages).
3. `firebase-config.js` is safe to commit publicly — those values aren't
   secret, the Firestore rules are what actually protect the data.

## How it behaves afterwards
- A visitor posts a comment → it's saved as **pending** → hidden from
  everyone.
- You log into `admin.html` with the email/password from step 4 →
  **Comment moderation** panel shows every comment (pending/approved/
  rejected) → **Approve**, **Reject**, or **Delete**.
- The moment you approve one, it appears for **every visitor, on every
  browser**, immediately — no manual file editing needed.

Reactions and the visitor/traffic log are unchanged and still stored only
in each visitor's own browser (`localStorage`), since that wasn't part of
this request.
